package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Model1;

public class Daoimplementation implements Daointerface
{
   SessionFactory sf=null;
   public Daoimplementation()
   {
	   Configuration cfg=new Configuration().configure().addAnnotatedClass(Model1.class);
	   sf=cfg.buildSessionFactory();
   }
   
	public void addstudent(Model1 m) {
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(m);
		tx.commit();
		session.close();
	}

	public void deletestudent(Model1 m, String s) {
		
	}

	public void searchStudent(Model1 m) {
		
	}

	public void viewAllStudent(Model1 m) {
		
	}

	public void updateStudent(Model1 m) {
	
	}

}
