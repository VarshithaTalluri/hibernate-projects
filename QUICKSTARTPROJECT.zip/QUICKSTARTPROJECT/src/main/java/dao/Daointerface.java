package dao;

import model.Model1;

public interface Daointerface
{
public void addstudent(Model1 m);
public void deletestudent(Model1 m,String s);
public void searchStudent(Model1 m);
public void viewAllStudent(Model1 m);
public void updateStudent(Model1 m);

}
