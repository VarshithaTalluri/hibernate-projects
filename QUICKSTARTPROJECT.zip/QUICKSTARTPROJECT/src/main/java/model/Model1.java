package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Model1
{
@Id
private String sid;
private String name;
private long mobile;
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}

}
