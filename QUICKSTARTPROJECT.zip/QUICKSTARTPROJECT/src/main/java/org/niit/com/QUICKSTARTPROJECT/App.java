package org.niit.com.QUICKSTARTPROJECT;

import java.util.Scanner;

import model.Model1;

public class App 
{
	Scanner s= null;
	public Model1 insert() {
    Model1 m=new Model1();
    System.out.println("enter");
		return m;
		
	}
    public static void main( String[] args )
    {
        
    }
}
