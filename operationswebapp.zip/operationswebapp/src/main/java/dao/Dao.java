package dao;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Student;

public class Dao 
{
	SessionFactory sf=null;
	public Dao()
	{
		Configuration  cfg=new Configuration().configure().addAnnotatedClass(Student.class);
		sf=cfg.buildSessionFactory();
		
	}
	public void insert(Student s)
	{
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(s);
		tx.commit();
		sf.close();
	}

}
