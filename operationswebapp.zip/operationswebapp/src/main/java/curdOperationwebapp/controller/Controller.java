package curdOperationwebapp.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.Student;

@WebServlet(urlPatterns = {"/reqreg"})
public class Controller extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)
	{
		String path=req.getServletPath();
		if(path.equals("/reqreg"))
		{
			Student s=new Student();
			s.setSid(req.getParameter("t1"));
			s.setName(req.getParameter("t2"));
			s.setEmail(req.getParameter("t3"));
			s.setMarks(req.getParameter("t4"));
			s.setCity(req.getParameter("t5"));
			new Dao().insert(s);
		}
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)
	{
		
	}

}
