package springhibernateusingcurd.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StudentModel
{
	@Id
	private String sid;
	private String sname,city;
	private int marks;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
}
