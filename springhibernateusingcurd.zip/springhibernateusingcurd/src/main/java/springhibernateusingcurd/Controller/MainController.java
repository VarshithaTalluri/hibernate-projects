package springhibernateusingcurd.Controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import springhibernateusingcurd.dao.DaoImpl;
import springhibernateusingcurd.dao.DaoInterface;
import springhibernateusingcurd.model.StudentModel;


@Controller
public class MainController 
{ 

	DaoInterface di = null;
   @RequestMapping("/reqreg")
   public String reg(@ModelAttribute("studentmodel") StudentModel sm)
    {
	   boolean b=false;
	   System.out.println("student id:"+sm.getSid());
       di=new DaoImpl();
       b=di.reg(sm);
       if(b)
       {
    	   return "welcome.jsp";
       }
       else
       {
    	   return "index.jsp";
       }
      }
   @RequestMapping("/reqallstudent")
	  public ModelAndView viewAllStudents()
	  {
		  List<StudentModel> sm=null;
		  di=new DaoImpl();
		  sm=di.selectAllStudents();
		  ModelAndView mav=new ModelAndView();
		  mav.addObject("students",sm);
		  mav.setViewName("allStudents.jsp");
		  return mav;
	  }
	  
	  @RequestMapping("/reqsearch")
	  public ModelAndView search(@RequestParam("search") String search)
	  {
		  StudentModel sm=null;
		  di=new DaoImpl();
		  sm=di.search(search);
		  ModelAndView mav=new ModelAndView();
		  mav.addObject("student",sm);
		  mav.setViewName("search.jsp");
		  
		  return mav;
	  }
	 
	  
	  @RequestMapping("/reqdelete")
	  public String deleteStudent(@RequestParam("sid") String sid)
	  {
		  System.out.println("Controller:Sid:"+sid);
		  StudentModel sm=new StudentModel();
		  boolean b=false;
		  di=new DaoImpl();
		  b=di.deleteStudent(sid);
		  if(b)
			  return "hai";
		  else
			  return "index.jsp";
		  
	  }

	  @RequestMapping("/requpdate")
	 public ModelAndView getDataToUpdate(@RequestParam("sid") String sid)
	 {
		 StudentModel sm=new StudentModel();
		 sm.setSid(sid);
		  di=new DaoImpl();
		  sm=di.getDataToUpdate(sm);
		  System.out.println(sm);
		 sm=di.search(sid);
		 System.out.println(sm);
		 ModelAndView mav=new ModelAndView();
		 mav.addObject("student",sm);
		 mav.setViewName("updateform.jsp");
		 return mav;
	 }   

	  @RequestMapping("/requpdatestudent")
	  public String updateStudentInfo(@ModelAttribute("student") StudentModel sm)
	  {
		  boolean b=false;
		  di=new DaoImpl();
		  b=di.updateStudentInfo(sm);
		  if(b)
			  return "index.jsp";
		  else
			  return "index.jsp";
			  
	  }
}
