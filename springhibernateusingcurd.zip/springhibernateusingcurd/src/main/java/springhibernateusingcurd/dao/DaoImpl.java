package springhibernateusingcurd.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import springhibernateusingcurd.model.StudentModel;

public class DaoImpl implements DaoInterface
{
	SessionFactory sf=null;
	public DaoImpl()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(StudentModel.class);
	    sf=cfg.buildSessionFactory();
	}
 public boolean reg(StudentModel sm)
 {
	 boolean b=false;
	 Session session=sf.openSession();
	 Transaction tx=session.beginTransaction();
	 Object obj=session.save(sm);
	 if(obj!=null)
	 {
		 b=true;
		 tx.commit();
		 session.close();
	 }
	return b;
 }
	 public ArrayList<StudentModel> selectAllStudents() 
		{
			Session session=sf.openSession();
		    ArrayList<StudentModel> al=new ArrayList();
		    al=(ArrayList<StudentModel>) session.createQuery("from StudentModel").list();
			return al;
		}
	 public StudentModel search(String sid) 
		{
			StudentModel sm=null;
			Session session=sf.openSession();
			sm=(StudentModel)session.get(StudentModel.class, sid);
			session.close();
			return sm;
		}
	 public boolean deleteStudent(String sid) 
		{
			StudentModel sm=new StudentModel();
			sm.setSid(sid);
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			System.out.println("hello"+sid);
			session.delete(sm);  
			tx.commit();
			session.close();
			
			return false;
		}
	 public StudentModel getDataToUpdate(StudentModel sm)
		{
			Session session=sf.openSession();
			sm=(StudentModel)session.get(StudentModel.class, sm.getSid());
			session.close();
			return sm;
		}
		public boolean updateStudentInfo(StudentModel sm) {
			
			boolean b=false;
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			session.update(sm);
			b=true;
			tx.commit();
			session.close();
			return b;
		}
		
		}
