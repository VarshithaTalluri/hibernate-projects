package springhibernateusingcurd.dao;

import java.util.List;

import springhibernateusingcurd.model.StudentModel;

public interface DaoInterface 
{
	public boolean reg(StudentModel sm);
	public List<StudentModel> selectAllStudents();
	public StudentModel search(String sid);
	public boolean deleteStudent(String sid);
	public StudentModel getDataToUpdate(StudentModel sm);
	public boolean updateStudentInfo(StudentModel sm);
	

	
}
