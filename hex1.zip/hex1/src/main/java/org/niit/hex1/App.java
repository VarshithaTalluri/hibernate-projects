package org.niit.hex1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.niit.hex1.model.Student;

public class App 
{
    public static void main( String[] args )
    {
    	Student s=new Student();
    	s.setName("varshitha");
    	s.setMarks(90);
    	s.setCity("vijayawada");
    	s.setEmail("varshi@gmail.com");
    	s.setGender("female");
    	
    	Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
    	SessionFactory sf=cfg.buildSessionFactory();
    	
    	Session session=sf.openSession();
    	Transaction t=session.beginTransaction();
    	session.save(s);
    	t.commit();
    }
}
